# Krishna Kuteer Apartment – Maintenance App

Static website (one `index.html`). All data is stored in a Google Sheet through a Google Apps Script.

```
index.html            the app (set SCRIPT_URL inside)
_headers              Cloudflare security headers
robots.txt            keeps search engines out
apps-script/Code.gs   paste into the Google Sheet's Apps Script
```

## 1. Google Sheet backend (once)
1. New Google Sheet → **Extensions → Apps Script** → paste `apps-script/Code.gs` → Save.
2. Run **`setup`** once and approve permissions.
3. **Deploy → New deployment → Web app** → Execute as **Me**, Access **Anyone** → copy the URL.
4. Open `index.html`, find `const SCRIPT_URL="PASTE_YOUR_WEB_APP_URL_HERE";` and paste the URL.

## 2. Put the files on GitHub
Easiest: create a new **private** repo on github.com → **Add file → Upload files** → drag in everything in this folder → Commit.

Or with git:
```
git init && git add . && git commit -m "Krishna Kuteer app"
git branch -M main
git remote add origin https://github.com/YOUR-USER/krishna-kuteer.git
git push -u origin main
```

## 3. Host on Cloudflare Pages
1. Cloudflare dashboard → **Workers & Pages → Create → Pages → Connect to Git**.
2. Pick the repo → **Begin setup**.
3. Framework preset: **None**. Build command: *(leave empty)*. Build output directory: **/** (or leave blank).
4. **Save and Deploy**. Your site is live at `https://<project>.pages.dev`.
5. Optional: **Custom domains** tab to use your own domain.

Every later change: edit the file on GitHub → Commit → Cloudflare redeploys in about a minute.

## Notes
- Changed `Code.gs`? In Apps Script use **Deploy → Manage deployments → Edit → New version** (the URL stays the same).
- Starter passwords: flats `123456`, admin `1234` / `987654`. Everyone must change them on first sign-in.
- Edit the `flats` and `users` tabs in the Sheet to match your real flats. Don't share the Sheet with residents (it holds login data).
- If something is blocked after deploy, check the browser console; the `Content-Security-Policy` line in `_headers` can be removed to test.
