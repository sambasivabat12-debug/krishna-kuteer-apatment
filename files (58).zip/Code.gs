/* Krishna Kuteer - Google Sheets backend.
   Paste into Extensions > Apps Script of your Google Sheet, run setup() once, then Deploy > Web app. */

const TABLES = {
  flats: ['id', 'flat_no', 'monthly_amount'],
  payments: ['id', 'receipt_no', 'flat_id', 'month', 'amount', 'paid_on', 'mode', 'reference', 'remarks', 'created_at'],
  expenses: ['id', 'spent_on', 'category', 'amount', 'paid_to', 'mode', 'description', 'remarks', 'created_at'],
  income: ['id', 'received_on', 'category', 'amount', 'mode', 'remarks', 'created_at'],
  maintenance_rates: ['month', 'amount'],
  closed_months: ['month', 'closing_cash', 'closing_bank', 'closed_at'],
  notices: ['id', 'title', 'created_on'],
  settings: ['id', 'opening_cash', 'opening_bank'],
  users: ['username', 'role', 'flat_id', 'temp_password', 'password_hash', 'salt']
};
const TEXT_COLS = ['month', 'paid_on', 'spent_on', 'received_on', 'created_on', 'created_at', 'closed_at',
                   'flat_no', 'username', 'temp_password', 'password_hash', 'salt'];
const STR_COLS = ['flat_no', 'username', 'temp_password'];
const W = ['admin', 'treasurer', 'secretary'], N = ['admin', 'president', 'secretary'], A = ['admin', 'treasurer'];
const RULES = {
  payments: { insert: W }, expenses: { insert: W, delete: A }, income: { insert: W, delete: A },
  maintenance_rates: { upsert: W }, closed_months: { insert: W, delete: ['admin'] },
  notices: { insert: N, delete: N }, settings: { update: A }
};
const DATE_OF = { payments: ['paid_on', 'month'], expenses: ['spent_on'], income: ['received_on'], maintenance_rates: ['month'] };

/* ---------- one-time setup: creates the tabs and starter data ---------- */
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(TABLES).forEach(t => {
    const cols = TABLES[t], sh = ss.getSheetByName(t) || ss.insertSheet(t);
    if (sh.getLastRow() === 0) { sh.getRange(1, 1, 1, cols.length).setValues([cols]).setFontWeight('bold'); sh.setFrozenRow(1); }
    cols.forEach((c, i) => { if (TEXT_COLS.indexOf(c) >= 0) sh.getRange(1, i + 1, sh.getMaxRows(), 1).setNumberFormat('@'); });
  });
  const first = ss.getSheetByName('Sheet1'); if (first && first.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(first);
  if (!read_('flats').length) {
    ['101', '102', '201', '202', '301', '302', '401', '402', '501', '502'].forEach((n, i) => {
      sh_('flats').appendRow([i + 1, n, 1000]);
      sh_('users').appendRow([n, 'resident', i + 1, '123456', '', '']);
    });
    sh_('users').appendRow(['1234', 'admin', '', '987654', '', '']);
  }
  if (!read_('settings').length) sh_('settings').appendRow([1, 0, 0]);
  Logger.log('Setup done. Now: Deploy > New deployment > Web app (Execute as: Me, Access: Anyone).');
}

/* ---------- web endpoint ---------- */
function doGet() { return ContentService.createTextOutput('Krishna Kuteer API is running'); }
function doPost(e) {
  let out;
  try { out = route_(JSON.parse(e.postData.contents)); } catch (err) { out = { error: { message: 'Server error: ' + err.message } }; }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}
function route_(b) {
  if (b.a === 'login') return login_(b);
  const u = session_(b.token);
  if (!u) return { auth: true, error: { message: 'Session expired. Please sign in again.' } };
  if (b.a === 'me') return { user: pub_(u) };
  if (b.a === 'snapshot') return { data: snapshot_(u) };
  if (b.a === 'logout') { CacheService.getScriptCache().remove('t_' + b.token); return { ok: true }; }
  if (b.a === 'pw' || b.a === 'write') {
    const lock = LockService.getScriptLock(); lock.waitLock(20000);
    try { return b.a === 'pw' ? pw_(u, b) : write_(u, b); } finally { lock.releaseLock(); }
  }
  return { error: { message: 'Unknown request' } };
}

/* ---------- sheet helpers ---------- */
const sh_ = t => SpreadsheetApp.getActiveSpreadsheet().getSheetByName(t);
function read_(t) {
  const v = sh_(t).getDataRange().getValues(), h = v[0], tz = SpreadsheetApp.getActiveSpreadsheet().getSpreadsheetTimeZone();
  return v.slice(1).map((r, i) => {
    const o = { __r: i + 2 };
    h.forEach((k, j) => {
      let x = r[j];
      if (x instanceof Date) x = Utilities.formatDate(x, tz, k === 'created_at' || k === 'closed_at' ? 'yyyy-MM-dd HH:mm' : 'yyyy-MM-dd');
      o[k] = x === '' ? null : (STR_COLS.indexOf(k) >= 0 ? String(x) : x);
    });
    return o;
  }).filter(o => TABLES[t].some(k => o[k] !== null));
}
const clean_ = rows => rows.map(r => { const o = Object.assign({}, r); delete o.__r; return o; });
const nextId_ = (t, c) => read_(t).reduce((m, r) => Math.max(m, +r[c] || 0), 0) + 1;
const now_ = () => Utilities.formatDate(new Date(), SpreadsheetApp.getActiveSpreadsheet().getSpreadsheetTimeZone(), 'yyyy-MM-dd HH:mm');

/* ---------- login / sessions ---------- */
const hash_ = (p, salt) => Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + p));
const pub_ = u => ({ id: u.username, email: u.username + '@krishnakuteer.app', role: u.role, flat: u.flat_id, pw_changed: !!u.password_hash });
function findUser_(name) {
  name = String(name || '').trim().toLowerCase().replace(/@krishnakuteer\.app$/, '');
  return read_('users').filter(u => String(u.username).trim().toLowerCase() === name)[0] || null;
}
function login_(b) {
  const cache = CacheService.getScriptCache(), key = 'f_' + String(b.u).toLowerCase(), fails = +cache.get(key) || 0;
  if (fails >= 8) return { error: { message: 'Too many wrong attempts. Please wait 10 minutes and try again.' } };
  const u = findUser_(b.u), p = String(b.p || '');
  const ok = u && (u.password_hash ? hash_(p, u.salt) === u.password_hash : (u.temp_password && String(u.temp_password) === p));
  if (!ok) { cache.put(key, String(fails + 1), 600); return { error: { message: 'Invalid login credentials' } }; }
  cache.remove(key);
  const token = Utilities.getUuid() + Utilities.getUuid();
  cache.put('t_' + token, u.username, 21600);
  return { token: token, user: pub_(u) };
}
function session_(token) {
  const name = token && CacheService.getScriptCache().get('t_' + token);
  return name ? findUser_(name) : null;
}
function pw_(u, b) {
  const p = String(b.password || '');
  if (p.length < 6) return { error: { message: 'Password must be at least 6 characters.' } };
  const salt = Utilities.getUuid(), sh = sh_('users'), h = TABLES.users;
  sh.getRange(u.__r, h.indexOf('password_hash') + 1).setValue(hash_(p, salt));
  sh.getRange(u.__r, h.indexOf('salt') + 1).setValue(salt);
  sh.getRange(u.__r, h.indexOf('temp_password') + 1).setValue('');
  return { ok: true };
}

/* ---------- reading ---------- */
function snapshot_(u) {
  const T = {};
  ['flats', 'payments', 'expenses', 'income', 'maintenance_rates', 'closed_months', 'notices', 'settings'].forEach(t => T[t] = clean_(read_(t)));
  T.profiles = [{ id: u.username, role: u.role, flat_id: u.flat_id }];
  T.balance = u.role === 'resident' ? [] : [balance_(T)];
  return T;
}
function balance_(T) {
  const s = T.settings[0] || {}, k = r => (r.mode || 'cash') === 'cash' ? 'cash' : 'bank';
  const v = { cash: +s.opening_cash || 0, bank: +s.opening_bank || 0 }, open = v.cash + v.bank;
  let rec = 0, spent = 0;
  T.payments.forEach(p => { v[k(p)] += +p.amount; rec += +p.amount; });
  T.income.filter(i => i.category === 'other').forEach(p => { v[k(p)] += +p.amount; rec += +p.amount; });
  T.expenses.forEach(p => { v[k(p)] -= +p.amount; spent += +p.amount; });
  return { opening_balance: open, received: rec, spent: spent, cash: v.cash, bank: v.bank, closing: v.cash + v.bank };
}

/* ---------- writing (permissions + month locks enforced here) ---------- */
function write_(u, b) {
  const t = b.t, op = b.op, allowed = RULES[t] && RULES[t][op], err = m => ({ error: { message: m } });
  if (!allowed || allowed.indexOf(u.role) < 0) return err('You do not have permission to do this.');
  const closed = read_('closed_months').map(r => String(r.month).slice(0, 7));
  const locked = d => d && closed.indexOf(String(d).slice(0, 7)) >= 0;
  const LOCKMSG = 'This month is locked. Nothing can be added, changed or deleted in it.';
  const cols = TABLES[t], sh = sh_(t), p = b.payload || {};
  const find = () => read_(t).filter(r => (b.filters || []).every(f => String(r[f[0]]) === String(f[1])));

  if (op === 'insert' || op === 'upsert') {
    if (t !== 'closed_months' && (DATE_OF[t] || []).some(c => locked(p[c]))) return err(LOCKMSG);
    if (['payments', 'expenses', 'income'].indexOf(t) >= 0 && !(+p.amount > 0)) return err('Enter an amount above 0.');
    if (t === 'closed_months' && closed.indexOf(String(p.month).slice(0, 7)) >= 0) return err('This month is already closed.');
  }
  if (op === 'insert') {
    const rec = Object.assign({}, p);
    if (cols.indexOf('id') >= 0) rec.id = nextId_(t, 'id');
    if (t === 'payments') rec.receipt_no = nextId_(t, 'receipt_no');
    if (cols.indexOf('created_at') >= 0) rec.created_at = now_();
    if (t === 'notices') rec.created_on = now_().slice(0, 10);
    if (t === 'closed_months') rec.closed_at = now_();
    sh.appendRow(cols.map(c => rec[c] == null ? '' : rec[c]));
    return { ok: true };
  }
  if (op === 'upsert') {
    const key = b.onConflict, hit = read_(t).filter(r => String(r[key]) === String(p[key]))[0];
    if (!hit) { sh.appendRow(cols.map(c => p[c] == null ? '' : p[c])); return { ok: true }; }
    cols.forEach((c, i) => { if (p[c] != null && c !== key) sh.getRange(hit.__r, i + 1).setValue(p[c]); });
    return { ok: true };
  }
  if (op === 'update') {
    const rows = find(); if (!rows.length) return err('Record not found.');
    rows.forEach(r => cols.forEach((c, i) => { if (p[c] != null && c !== 'id') sh.getRange(r.__r, i + 1).setValue(p[c]); }));
    return { ok: true };
  }
  if (op === 'delete') {
    const rows = find();
    if (rows.some(r => (DATE_OF[t] || []).some(c => locked(r[c])))) return err(LOCKMSG);
    rows.map(r => r.__r).sort((x, y) => y - x).forEach(n => sh.deleteRow(n));
    return { ok: true };
  }
  return err('Unsupported action.');
}
